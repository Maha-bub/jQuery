<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
/* Destroy only donor session keys */
$keys = ['donor_id','donor_name','donor_email','guest_access','guest_name','csrf','flash'];
foreach ($keys as $k) unset($_SESSION[$k]);
if (session_status() === PHP_SESSION_ACTIVE) {
    session_regenerate_id(true);
    session_destroy();
}
header('Location: ' . BASE_URL . '/auth/login.php');
exit;
