<?php
/* ============================================================
   auth/login.php — Donor Login + Choice Screen
   ============================================================ */
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (donor_logged_in() || guest_allowed()) {
    header('Location: ' . BASE_URL . '/');
    exit;
}

$flash = flash_get();
$error = '';
$mode  = $_GET['mode'] ?? '';   // '' = choice | 'login' = form
$next  = $_GET['next']  ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('Invalid token.'); }

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Both fields are required.';
        $mode  = 'login';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND status = "active"');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['donor_id']    = $user['id'];
            $_SESSION['donor_name']  = $user['name'];
            $_SESSION['donor_email'] = $user['email'];

            /* Track login */
            bump_login_count($pdo, 'users', $user['id']);

            $go = (!empty($next) && str_starts_with($next, '/')) ? $next : BASE_URL . '/';
            header('Location: ' . $go);
            exit;
        } else {
            $error = 'Invalid email or password.';
            $mode  = 'login';
        }
    }
}
$base = BASE_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $mode === 'login' ? 'Login' : 'Welcome' ?> — Esho Desh Gori</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --green:    #1a7a4a;
  --green-dk: #0f5432;
  --green-lt: #23a063;
  --gold:     #d4a017;
  --gold-lt:  #f0c040;
  --white:    #ffffff;
  --dark:     #1a1a1a;
  --gray:     #6b7280;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  background: #f0faf4;
}

/* ── LEFT PANEL ── */
.left-panel {
  background: linear-gradient(155deg, var(--green-dk) 0%, var(--green) 60%, var(--green-lt) 100%);
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  padding: 48px 40px; position: relative; overflow: hidden;
  min-height: 100vh;
}

/* Decorative circles */
.left-panel::before {
  content: ''; position: absolute; top: -100px; right: -100px;
  width: 350px; height: 350px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.08); pointer-events: none;
}
.left-panel::after {
  content: ''; position: absolute; bottom: -80px; left: -80px;
  width: 280px; height: 280px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.06); pointer-events: none;
}

.lp-logo {
  width: 80px; height: 80px; border-radius: 50%;
  background: rgba(255,255,255,0.12);
  border: 2px solid rgba(255,255,255,0.2);
  display: flex; align-items: center; justify-content: center;
  font-size: 32px; margin-bottom: 28px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.2);
  position: relative; z-index: 1;
}

.lp-title {
  font-family: 'Playfair Display', serif;
  font-size: 34px; font-weight: 700; color: #fff;
  text-align: center; margin-bottom: 6px;
  position: relative; z-index: 1;
}

.lp-bangla {
  font-size: 15px; color: rgba(255,255,255,0.65);
  text-align: center; margin-bottom: 40px;
  position: relative; z-index: 1;
}

.lp-divider {
  width: 60px; height: 3px; background: var(--gold);
  border-radius: 2px; margin: 0 auto 36px;
  position: relative; z-index: 1;
}

.lp-features {
  display: flex; flex-direction: column; gap: 18px;
  width: 100%; max-width: 320px;
  position: relative; z-index: 1;
}

.lp-feature {
  display: flex; align-items: center; gap: 14px;
  background: rgba(255,255,255,0.09);
  border: 1px solid rgba(255,255,255,0.13);
  border-radius: 14px; padding: 14px 18px;
}

.lp-feature-icon {
  width: 38px; height: 38px; border-radius: 10px;
  background: rgba(255,255,255,0.12);
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; flex-shrink: 0;
}

.lp-feature-text .ft-title {
  font-size: 13px; font-weight: 600; color: #fff; margin-bottom: 2px;
}
.lp-feature-text .ft-sub {
  font-size: 11px; color: rgba(255,255,255,0.55); line-height: 1.4;
}

.lp-quote {
  margin-top: 36px; padding: 18px 22px;
  background: rgba(212,160,23,0.15);
  border: 1px solid rgba(212,160,23,0.3);
  border-radius: 12px; max-width: 320px; width: 100%;
  position: relative; z-index: 1;
}
.lp-quote p {
  font-size: 12.5px; color: rgba(255,255,255,0.75);
  line-height: 1.6; font-style: italic;
}
.lp-quote cite {
  display: block; margin-top: 8px; font-size: 11px;
  color: var(--gold-lt); font-style: normal; font-weight: 600;
}

/* ── RIGHT PANEL ── */
.right-panel {
  display: flex; align-items: center; justify-content: center;
  padding: 48px 40px; background: #f8fdf9;
}

.form-wrap { width: 100%; max-width: 420px; }

.form-heading {
  font-family: 'Playfair Display', serif;
  font-size: 26px; font-weight: 700; color: var(--dark); margin-bottom: 6px;
}
.form-sub { font-size: 13px; color: var(--gray); margin-bottom: 32px; }

/* Choice cards */
.choice-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 24px; }

.choice-card {
  border-radius: 16px; padding: 22px 16px; text-align: center;
  cursor: pointer; transition: all .22s; text-decoration: none;
  display: flex; flex-direction: column; align-items: center; gap: 10px;
  border: 2px solid transparent;
}

.choice-card.cc-account {
  background: #e8f5ee; border-color: #b8ddc8; color: var(--green-dk);
}
.choice-card.cc-account:hover {
  background: var(--green); border-color: var(--green);
  transform: translateY(-4px); box-shadow: 0 12px 32px rgba(26,122,74,.3);
}
.choice-card.cc-account:hover .cc-icon,
.choice-card.cc-account:hover .cc-title,
.choice-card.cc-account:hover .cc-desc { color: #fff; }

.choice-card.cc-guest {
  background: #fef9ec; border-color: #f0d98a; color: #92400e;
}
.choice-card.cc-guest:hover {
  background: var(--gold); border-color: var(--gold);
  transform: translateY(-4px); box-shadow: 0 12px 32px rgba(212,160,23,.3);
}
.choice-card.cc-guest:hover .cc-icon,
.choice-card.cc-guest:hover .cc-title,
.choice-card.cc-guest:hover .cc-desc { color: var(--dark); }

.cc-icon  { font-size: 28px; transition: color .22s; }
.cc-title { font-size: 14px; font-weight: 700; transition: color .22s; }
.cc-desc  { font-size: 11px; line-height: 1.45; transition: color .22s; color: inherit; opacity: .8; }

.cc-badge {
  font-size: 10px; font-weight: 700; padding: 3px 10px;
  border-radius: 20px; letter-spacing: .8px; text-transform: uppercase;
}
.cc-account .cc-badge { background: #d1fae5; color: #065f46; }
.cc-guest   .cc-badge { background: #fde68a; color: #92400e; }

.or-line {
  text-align: center; font-size: 12px; color: #9ca3af;
  margin: 4px 0 16px; position: relative;
}
.or-line::before, .or-line::after {
  content: ''; position: absolute; top: 50%;
  width: 42%; height: 1px; background: #e5e7eb;
}
.or-line::before { left: 0; }
.or-line::after  { right: 0; }

.admin-link {
  text-align: center; font-size: 12px; color: var(--gray);
  padding-top: 14px; border-top: 1px solid #e8f5ec;
}
.admin-link a { color: var(--green); font-weight: 600; text-decoration: none; }
.admin-link a:hover { text-decoration: underline; }

.new-link {
  text-align: center; font-size: 13px; color: var(--gray); margin-bottom: 20px;
}
.new-link a { color: var(--green); font-weight: 600; text-decoration: none; }

/* Login form */
.form-group { margin-bottom: 16px; }
.form-label {
  display: block; font-size: 13px; font-weight: 600;
  color: var(--dark); margin-bottom: 5px;
}

.input-wrap {
  position: relative;
}
.input-wrap i {
  position: absolute; left: 14px; top: 50%;
  transform: translateY(-50%); color: var(--gray); font-size: 14px;
}
.input-wrap input {
  width: 100%; padding: 12px 14px 12px 40px;
  border: 1.5px solid #d1e8d9; border-radius: 12px;
  font-family: 'DM Sans', sans-serif; font-size: 14px; color: var(--dark);
  background: #fafdfb; outline: none; transition: all .2s;
}
.input-wrap input:focus {
  border-color: var(--green);
  box-shadow: 0 0 0 3px rgba(26,122,74,.1);
  background: #fff;
}
.input-wrap input::placeholder { color: #b0bec5; }

/* Password toggle */
.pw-toggle {
  position: absolute; right: 14px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--gray); font-size: 14px; padding: 0;
}
.pw-toggle:hover { color: var(--green); }

.btn-login {
  width: 100%; background: linear-gradient(135deg, var(--green-dk), var(--green));
  color: #fff; border: none; border-radius: 30px; padding: 14px;
  font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 700;
  cursor: pointer; transition: all .22s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  box-shadow: 0 4px 18px rgba(26,122,74,.35); margin-top: 6px;
}
.btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,74,.45); }

.back-btn-sm {
  display: inline-flex; align-items: center; gap: 7px;
  font-size: 13px; color: var(--gray); text-decoration: none;
  margin-bottom: 24px; transition: color .2s;
}
.back-btn-sm:hover { color: var(--green); }

.alert-error {
  background: #fff5f5; border: 1px solid #f5c6cb;
  border-radius: 10px; padding: 11px 14px;
  font-size: 13px; color: #c0392b; margin-bottom: 18px;
  display: flex; align-items: center; gap: 8px;
}
.alert-success {
  background: #e8f5ee; border: 1px solid #a8d5b8;
  border-radius: 10px; padding: 11px 14px;
  font-size: 13px; color: #0f5432; margin-bottom: 18px;
  display: flex; align-items: center; gap: 8px;
}

@media (max-width: 820px) {
  body { grid-template-columns: 1fr; }
  .left-panel { min-height: 220px; padding: 32px 24px; }
  .lp-features, .lp-quote { display: none; }
  .lp-title { font-size: 26px; margin-bottom: 4px; }
  .right-panel { padding: 32px 24px; }
}
@media (max-width: 480px) {
  .choice-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<!-- ── LEFT PANEL ── -->
<div class="left-panel">
  <div class="lp-logo"><i class="fas fa-hands-holding-heart"></i></div>
  <div class="lp-title">Esho Desh Gori</div>
  <div class="lp-bangla">এসো দেশ গড়ি</div>
  <div class="lp-divider"></div>

  <div class="lp-features">
    <div class="lp-feature">
      <div class="lp-feature-icon"><i class="fas fa-heart" style="color:#f9e49a;"></i></div>
      <div class="lp-feature-text">
        <div class="ft-title">Make a Real Impact</div>
        <div class="ft-sub">Your donation reaches families in need within 24 hours</div>
      </div>
    </div>
    <div class="lp-feature">
      <div class="lp-feature-icon"><i class="fas fa-shield-halved" style="color:#86efac;"></i></div>
      <div class="lp-feature-text">
        <div class="ft-title">100% Secure &amp; Transparent</div>
        <div class="ft-sub">Every taka is tracked and accounted for</div>
      </div>
    </div>
    <div class="lp-feature">
      <div class="lp-feature-icon"><i class="fas fa-users" style="color:#93c5fd;"></i></div>
      <div class="lp-feature-text">
        <div class="ft-title">8,000+ Donors Worldwide</div>
        <div class="ft-sub">Join a growing community building a better Bangladesh</div>
      </div>
    </div>
  </div>

  <div class="lp-quote">
    <p>"The best of people are those who are most beneficial to others."</p>
    <cite>— Prophet Muhammad ﷺ</cite>
  </div>
</div>

<!-- ── RIGHT PANEL ── -->
<div class="right-panel">
  <div class="form-wrap">

    <?php if ($mode === 'login'): ?>
    <!-- ══════════════════════ LOGIN FORM ══════════════════════ -->
    <a href="<?= $base ?>/auth/login.php<?= $next ? '?next='.urlencode($next) : '' ?>"
       class="back-btn-sm">
      <i class="fas fa-arrow-left"></i> Back
    </a>

    <div class="form-heading">Welcome back 👋</div>
    <div class="form-sub">Login to your account to continue</div>

    <?php if ($flash): ?>
      <div class="alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <?= htmlspecialchars($flash['msg']) ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
      <?php if ($next): ?>
        <input type="hidden" name="next" value="<?= htmlspecialchars($next) ?>">
      <?php endif; ?>

      <div class="form-group">
        <label class="form-label">Email Address</label>
        <div class="input-wrap">
          <i class="fas fa-envelope"></i>
          <input type="email" name="email" placeholder="your@email.com" autofocus required>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Password</label>
        <div class="input-wrap">
          <i class="fas fa-lock"></i>
          <input type="password" name="password" id="loginPw" placeholder="Your password" required>
          <button type="button" class="pw-toggle" onclick="togglePw('loginPw',this)">
            <i class="fas fa-eye"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="btn-login">
        <i class="fas fa-right-to-bracket"></i> Login
      </button>
    </form>

    <div class="new-link" style="margin-top:20px;">
      Don't have an account? <a href="<?= $base ?>/auth/register.php">Create one free →</a>
    </div>

    <?php else: ?>
    <!-- ══════════════════════ CHOICE SCREEN ══════════════════════ -->
    <div class="form-heading">How would you like to<br>continue?</div>
    <div class="form-sub">Choose an option to access the website</div>

    <?php if ($flash): ?>
      <div class="alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <?= htmlspecialchars($flash['msg']) ?>
      </div>
    <?php endif; ?>

    <div class="choice-grid">
      <a href="<?= $base ?>/auth/login.php?mode=login<?= $next ? '&next='.urlencode($next) : '' ?>"
         class="choice-card cc-account">
        <i class="fas fa-user-circle cc-icon"></i>
        <div class="cc-title">Login / Register</div>
        <div class="cc-desc">Track your donations &amp; full history</div>
        <span class="cc-badge">Full Access</span>
      </a>

      <a href="<?= $base ?>/auth/guest.php<?= $next ? '?next='.urlencode($next) : '' ?>"
         class="choice-card cc-guest">
        <i class="fas fa-user-secret cc-icon"></i>
        <div class="cc-title">Browse as Guest</div>
        <div class="cc-desc">Explore &amp; donate without an account</div>
        <span class="cc-badge">Limited</span>
      </a>
    </div>

    <div class="or-line">or</div>

    <div class="new-link">
      New here? <a href="<?= $base ?>/auth/register.php">Create a free account →</a>
    </div>

    <div class="admin-link">
      Admin?
      <a href="<?= $base ?>/auth/admin-login.php">
        <i class="fas fa-shield-halved"></i> Admin Panel Login
      </a>
    </div>

    <?php endif; ?>

  </div><!-- end form-wrap -->
</div><!-- end right-panel -->

<script>
function togglePw(id, btn) {
  var inp = document.getElementById(id);
  var ico = btn.querySelector('i');
  if (inp.type === 'password') {
    inp.type = 'text';
    ico.classList.replace('fa-eye', 'fa-eye-slash');
  } else {
    inp.type = 'password';
    ico.classList.replace('fa-eye-slash', 'fa-eye');
  }
}
</script>
</body>
</html>
