<?php
/* ============================================================
   auth/admin-login.php — Admin Login
   ============================================================ */
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (admin_logged_in()) {
    header('Location: ' . BASE_URL . '/admin/');
    exit;
}

$error        = '';
$login_attempts = (int)($_SESSION['admin_login_attempts'] ?? 0);
$locked_until   = $_SESSION['admin_locked_until'] ?? 0;

/* Check lockout */
$is_locked = ($locked_until > time());

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_locked) {
    if (!csrf_verify()) { http_response_code(403); die('Invalid token.'); }

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Both fields are required.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM admins WHERE email = ?');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            /* Success — clear attempts, set session */
            $_SESSION['admin_login_attempts'] = 0;
            unset($_SESSION['admin_locked_until']);
            session_regenerate_id(true);
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['admin_role'] = $admin['role'];

            /* Track login */
            bump_login_count($pdo, 'admins', $admin['id']);

            header('Location: ' . BASE_URL . '/admin/');
            exit;
        } else {
            /* Failed attempt */
            $_SESSION['admin_login_attempts'] = $login_attempts + 1;
            $login_attempts++;

            if ($login_attempts >= 5) {
                $_SESSION['admin_locked_until'] = time() + 300; /* 5 min lockout */
                $error = 'Too many failed attempts. Account locked for 5 minutes.';
                $is_locked = true;
            } else {
                $remaining = 5 - $login_attempts;
                $error = 'Invalid credentials. ' . $remaining . ' attempt(s) remaining.';
            }
        }
    }
}

$base = BASE_URL;
$lock_mins = $is_locked ? ceil(($locked_until - time()) / 60) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — Esho Desh Gori</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --green:    #1a7a4a;
  --green-dk: #0f5432;
  --gold:     #d4a017;
  --gold-lt:  #f0c040;
  --bg:       #0d1117;
  --surface:  #161b22;
  --border:   rgba(255,255,255,0.08);
  --text:     #e6edf3;
  --muted:    #8b949e;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  background: var(--bg);
  display: flex; align-items: center; justify-content: center;
  padding: 24px 16px; position: relative; overflow: hidden;
}

/* Subtle bg gradient blobs */
body::before {
  content: ''; position: fixed; top: -200px; left: -200px;
  width: 500px; height: 500px; border-radius: 50%;
  background: radial-gradient(circle, rgba(26,122,74,.18) 0%, transparent 70%);
  pointer-events: none;
}
body::after {
  content: ''; position: fixed; bottom: -150px; right: -150px;
  width: 400px; height: 400px; border-radius: 50%;
  background: radial-gradient(circle, rgba(15,84,50,.15) 0%, transparent 70%);
  pointer-events: none;
}

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 24px;
  box-shadow: 0 24px 80px rgba(0,0,0,0.6);
  width: 100%; max-width: 420px;
  overflow: hidden; position: relative; z-index: 1;
}

/* Top green strip */
.card-top {
  background: linear-gradient(135deg, var(--green-dk), var(--green));
  padding: 36px 36px 30px; position: relative; overflow: hidden;
}
.card-top::before {
  content: ''; position: absolute; top: -60px; right: -60px;
  width: 180px; height: 180px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.08); pointer-events: none;
}
.card-top::after {
  content: ''; position: absolute; bottom: -40px; left: -40px;
  width: 140px; height: 140px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.06); pointer-events: none;
}

.shield-icon {
  width: 60px; height: 60px; border-radius: 50%;
  background: rgba(255,255,255,0.12);
  border: 2px solid rgba(255,255,255,0.2);
  display: flex; align-items: center; justify-content: center;
  font-size: 24px; margin-bottom: 18px;
  box-shadow: 0 6px 24px rgba(0,0,0,0.25);
  position: relative; z-index: 1;
}

.card-top h1 {
  font-family: 'Playfair Display', serif;
  font-size: 22px; font-weight: 700; color: #fff;
  margin-bottom: 5px; position: relative; z-index: 1;
}
.card-top p {
  font-size: 12.5px; color: rgba(255,255,255,0.6);
  position: relative; z-index: 1;
}

/* Security badge */
.security-badge {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14);
  border-radius: 20px; padding: 4px 12px;
  font-size: 10.5px; font-weight: 600; color: rgba(255,255,255,0.6);
  letter-spacing: .8px; text-transform: uppercase;
  margin-top: 14px; position: relative; z-index: 1;
}
.security-badge::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: #4ade80; animation: blink 2s infinite;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }

/* Form body */
.card-body { padding: 30px 36px 36px; }

.form-label {
  display: block; font-size: 12.5px; font-weight: 600;
  color: var(--muted); margin-bottom: 5px; letter-spacing: .3px;
}
.input-wrap { position: relative; margin-bottom: 18px; }
.input-wrap i.icon {
  position: absolute; left: 14px; top: 50%;
  transform: translateY(-50%); color: #484f58; font-size: 14px;
}
.input-wrap input {
  width: 100%; background: var(--bg);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 12px; color: var(--text);
  font-family: 'DM Sans', sans-serif; font-size: 14px;
  padding: 12px 14px 12px 40px; outline: none; transition: all .2s;
}
.input-wrap input:focus {
  border-color: var(--green);
  box-shadow: 0 0 0 3px rgba(26,122,74,.2);
}
.input-wrap input::placeholder { color: #484f58; }

.pw-toggle {
  position: absolute; right: 13px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: #484f58; font-size: 13px; padding: 0;
  transition: color .2s;
}
.pw-toggle:hover { color: var(--green); }

/* Attempt counter */
.attempt-bar {
  display: flex; gap: 5px; margin-bottom: 16px;
}
.attempt-dot {
  width: 8px; height: 8px; border-radius: 50%;
  background: rgba(255,255,255,0.1);
  transition: background .3s;
}
.attempt-dot.used { background: #ef4444; }

.btn-admin {
  width: 100%; background: linear-gradient(135deg, var(--green-dk), var(--green));
  color: #fff; border: none; border-radius: 30px; padding: 14px;
  font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 700;
  cursor: pointer; transition: all .22s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  box-shadow: 0 4px 18px rgba(26,122,74,.35); margin-top: 6px;
}
.btn-admin:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,74,.45); }
.btn-admin:disabled {
  background: #374151; cursor: not-allowed;
  box-shadow: none; transform: none;
}

.alert-error {
  background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25);
  border-radius: 10px; padding: 11px 14px;
  font-size: 13px; color: #fca5a5; margin-bottom: 18px;
  display: flex; align-items: center; gap: 8px;
}
.alert-locked {
  background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.25);
  border-radius: 10px; padding: 14px;
  font-size: 13px; color: #fcd34d; margin-bottom: 18px; text-align: center;
}
.alert-locked i { font-size: 22px; display: block; margin-bottom: 6px; }

.footer-links {
  text-align: center; margin-top: 22px; padding-top: 18px;
  border-top: 1px solid var(--border);
  display: flex; justify-content: center; gap: 24px;
}
.footer-links a {
  font-size: 12px; color: var(--muted); text-decoration: none; transition: color .2s;
}
.footer-links a:hover { color: var(--green); }

/* Countdown timer */
#lockTimer { font-weight: 700; color: #fcd34d; }
</style>
</head>
<body>

<div class="card">

  <!-- Top -->
  <div class="card-top">
    <div class="shield-icon"><i class="fas fa-shield-halved"></i></div>
    <h1>Admin Panel</h1>
    <p>Restricted access — authorized personnel only</p>
    <div class="security-badge">Secure Connection</div>
  </div>

  <!-- Body -->
  <div class="card-body">

    <?php if ($is_locked): ?>
      <div class="alert-locked">
        <i class="fas fa-lock"></i>
        Account temporarily locked.<br>
        Please wait <span id="lockTimer"><?= $lock_mins ?> min</span> before trying again.
      </div>
    <?php elseif ($error): ?>
      <div class="alert-error">
        <i class="fas fa-circle-exclamation"></i>
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <!-- Attempt indicators (5 dots) -->
    <?php if (!$is_locked && $login_attempts > 0): ?>
      <div class="attempt-bar">
        <?php for ($i = 0; $i < 5; $i++): ?>
          <div class="attempt-dot <?= $i < $login_attempts ? 'used' : '' ?>"></div>
        <?php endfor; ?>
        <span style="font-size:11px;color:#8b949e;margin-left:6px;">
          <?= $login_attempts ?>/5 attempts
        </span>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <label class="form-label">Admin Email</label>
      <div class="input-wrap">
        <i class="fas fa-envelope icon"></i>
        <input type="email" name="email" placeholder="admin@eshodeshgori.com"
               autofocus required <?= $is_locked ? 'disabled' : '' ?>>
      </div>

      <label class="form-label">Password</label>
      <div class="input-wrap">
        <i class="fas fa-lock icon"></i>
        <input type="password" name="password" id="adminPw"
               placeholder="••••••••" required <?= $is_locked ? 'disabled' : '' ?>>
        <button type="button" class="pw-toggle" onclick="togglePw('adminPw',this)">
          <i class="fas fa-eye"></i>
        </button>
      </div>

      <button type="submit" class="btn-admin" <?= $is_locked ? 'disabled' : '' ?>>
        <i class="fas fa-right-to-bracket"></i>
        <?= $is_locked ? 'Account Locked' : 'Login to Admin Panel' ?>
      </button>
    </form>

    <div class="footer-links">
      <a href="<?= $base ?>/auth/login.php">
        <i class="fas fa-user"></i> Donor Login
      </a>
      <a href="<?= $base ?>/">
        <i class="fas fa-home"></i> Main Website
      </a>
    </div>

  </div>
</div>

<script>
function togglePw(id, btn) {
  var inp = document.getElementById(id);
  var ico = btn.querySelector('i');
  inp.type = inp.type === 'password' ? 'text' : 'password';
  ico.classList.toggle('fa-eye');
  ico.classList.toggle('fa-eye-slash');
}

/* Live countdown for lock timer */
<?php if ($is_locked): ?>
var unlockAt = <?= $locked_until ?>;
function updateTimer() {
  var left = Math.max(0, unlockAt - Math.floor(Date.now()/1000));
  var m = Math.floor(left/60), s = left % 60;
  var el = document.getElementById('lockTimer');
  if (el) el.textContent = m + ':' + (s < 10 ? '0' : '') + s;
  if (left <= 0) location.reload();
}
updateTimer();
setInterval(updateTimer, 1000);
<?php endif; ?>
</script>
</body>
</html>
