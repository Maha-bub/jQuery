<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
/* Destroy only admin session keys */
$keys = ['admin_id','admin_name','admin_role','csrf','flash','admin_login_attempts','admin_locked_until'];
foreach ($keys as $k) unset($_SESSION[$k]);
if (session_status() === PHP_SESSION_ACTIVE) {
    session_regenerate_id(true);
    session_destroy();
}
header('Location: ' . BASE_URL . '/auth/admin-login.php');
exit;
