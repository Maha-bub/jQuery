<?php
/* ============================================================
   auth/register.php — Donor Registration
   ============================================================ */
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (donor_logged_in()) {
    header('Location: ' . BASE_URL . '/');
    exit;
}

$errors = []; $old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('Invalid token.'); }

    $old['name']    = $name    = trim(strip_tags($_POST['name']    ?? ''));
    $old['email']   = $email   = trim(strip_tags($_POST['email']   ?? ''));
    $old['phone']   = $phone   = trim(strip_tags($_POST['phone']   ?? ''));
    $old['city']    = $city    = trim(strip_tags($_POST['city']    ?? ''));
    $old['address'] = $address = trim(strip_tags($_POST['address'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm']  ?? '';

    if (empty($name))                               $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email address is required.';
    if (!preg_match('/^01[0-9]{9}$/', $phone))      $errors[] = 'Phone must be in format: 01XXXXXXXXX';
    if (strlen($password) < 6)                      $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm)                     $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'This email is already registered. Please login.';
        } else {
            $pdo->prepare(
                'INSERT INTO users (name,email,phone,city,address,password,status) VALUES (?,?,?,?,?,?,?)'
            )->execute([$name, $email, $phone, $city, $address,
                        password_hash($password, PASSWORD_BCRYPT), 'active']);

            flash_set('success', 'Account created successfully! Please login.');
            header('Location: ' . BASE_URL . '/auth/login.php?mode=login');
            exit;
        }
    }
}
$base = BASE_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register — Esho Desh Gori</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --green:    #1a7a4a;
  --green-dk: #0f5432;
  --green-lt: #23a063;
  --gold:     #d4a017;
  --gold-lt:  #f0c040;
  --white:    #ffffff;
  --dark:     #1a1a1a;
  --gray:     #6b7280;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  background: #f0faf4;
}

/* ── LEFT PANEL ── */
.left-panel {
  background: linear-gradient(155deg, var(--green-dk) 0%, var(--green) 60%, var(--green-lt) 100%);
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  padding: 48px 40px; position: relative; overflow: hidden; min-height: 100vh;
}
.left-panel::before {
  content: ''; position: absolute; top: -100px; right: -100px;
  width: 350px; height: 350px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.07); pointer-events: none;
}
.left-panel::after {
  content: ''; position: absolute; bottom: -80px; left: -80px;
  width: 280px; height: 280px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.05); pointer-events: none;
}
.lp-logo {
  width: 80px; height: 80px; border-radius: 50%;
  background: rgba(255,255,255,0.12);
  border: 2px solid rgba(255,255,255,0.2);
  display: flex; align-items: center; justify-content: center;
  font-size: 32px; margin-bottom: 24px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.2); position: relative; z-index: 1;
}
.lp-title {
  font-family: 'Playfair Display', serif;
  font-size: 30px; font-weight: 700; color: #fff;
  text-align: center; margin-bottom: 5px; position: relative; z-index: 1;
}
.lp-sub {
  font-size: 13px; color: rgba(255,255,255,0.6);
  text-align: center; margin-bottom: 36px; position: relative; z-index: 1;
}
.lp-divider {
  width: 50px; height: 3px; background: var(--gold);
  border-radius: 2px; margin: 0 auto 36px; position: relative; z-index: 1;
}

.lp-steps { width: 100%; max-width: 300px; position: relative; z-index: 1; }
.lp-step {
  display: flex; align-items: flex-start; gap: 14px; margin-bottom: 22px;
}
.step-circle {
  width: 36px; height: 36px; border-radius: 50%;
  background: rgba(255,255,255,0.15); border: 2px solid rgba(255,255,255,0.25);
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 700; color: #fff; flex-shrink: 0;
}
.step-info .si-title { font-size: 13px; font-weight: 600; color: #fff; margin-bottom: 2px; }
.step-info .si-sub   { font-size: 11px; color: rgba(255,255,255,0.55); line-height: 1.4; }

/* Already have account box */
.lp-login-box {
  margin-top: 32px; padding: 18px 22px;
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.14);
  border-radius: 14px; max-width: 300px; width: 100%;
  text-align: center; position: relative; z-index: 1;
}
.lp-login-box p { font-size: 12.5px; color: rgba(255,255,255,0.65); margin-bottom: 12px; }
.lp-login-btn {
  display: inline-flex; align-items: center; gap: 7px;
  background: rgba(255,255,255,0.12); border: 1.5px solid rgba(255,255,255,0.22);
  color: #fff; padding: 9px 22px; border-radius: 25px;
  font-size: 13px; font-weight: 600; text-decoration: none; transition: all .2s;
}
.lp-login-btn:hover { background: rgba(255,255,255,0.22); color: #fff; }

/* ── RIGHT PANEL ── */
.right-panel {
  display: flex; align-items: center; justify-content: center;
  padding: 40px 40px; background: #f8fdf9; overflow-y: auto;
}
.form-wrap { width: 100%; max-width: 440px; }

.back-btn-sm {
  display: inline-flex; align-items: center; gap: 7px;
  font-size: 13px; color: var(--gray); text-decoration: none;
  margin-bottom: 22px; transition: color .2s;
}
.back-btn-sm:hover { color: var(--green); }

.form-heading {
  font-family: 'Playfair Display', serif;
  font-size: 26px; font-weight: 700; color: var(--dark); margin-bottom: 5px;
}
.form-sub { font-size: 13px; color: var(--gray); margin-bottom: 28px; }

.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }

.form-group { margin-bottom: 14px; }
.form-group.full { grid-column: 1 / -1; }
.form-label {
  display: block; font-size: 12.5px; font-weight: 600;
  color: var(--dark); margin-bottom: 5px;
}
.req { color: #e53e3e; margin-left: 2px; }

.input-wrap { position: relative; }
.input-wrap i.icon {
  position: absolute; left: 13px; top: 50%;
  transform: translateY(-50%); color: var(--gray); font-size: 13px;
}
.input-wrap input {
  width: 100%; padding: 11px 14px 11px 38px;
  border: 1.5px solid #d1e8d9; border-radius: 11px;
  font-family: 'DM Sans', sans-serif; font-size: 13.5px; color: var(--dark);
  background: #fafdfb; outline: none; transition: all .2s;
}
.input-wrap input:focus {
  border-color: var(--green);
  box-shadow: 0 0 0 3px rgba(26,122,74,.1);
  background: #fff;
}
.input-wrap input::placeholder { color: #b0bec5; }
.pw-toggle {
  position: absolute; right: 12px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--gray); font-size: 13px; padding: 0;
}
.pw-toggle:hover { color: var(--green); }

/* Password strength bar */
.pw-strength { height: 3px; border-radius: 2px; background: #e5e7eb; margin-top: 5px; overflow: hidden; }
.pw-strength-bar { height: 100%; width: 0; border-radius: 2px; transition: width .3s, background .3s; }
.pw-hint { font-size: 11px; color: var(--gray); margin-top: 4px; }

.alert-error {
  background: #fff5f5; border: 1px solid #f5c6cb; border-radius: 10px;
  padding: 11px 14px; font-size: 12.5px; color: #c0392b; margin-bottom: 18px;
}
.alert-error li { margin-left: 16px; margin-bottom: 2px; }

.btn-register {
  width: 100%; background: linear-gradient(135deg, var(--green-dk), var(--green));
  color: #fff; border: none; border-radius: 30px; padding: 14px;
  font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 700;
  cursor: pointer; transition: all .22s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  box-shadow: 0 4px 18px rgba(26,122,74,.35); margin-top: 4px;
}
.btn-register:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,74,.45); }

.terms-note {
  font-size: 11.5px; color: var(--gray); text-align: center; margin-top: 12px;
}

@media (max-width: 820px) {
  body { grid-template-columns: 1fr; }
  .left-panel { min-height: 180px; padding: 28px 24px; }
  .lp-steps, .lp-login-box { display: none; }
  .lp-title { font-size: 24px; }
  .right-panel { padding: 28px 20px; }
}
@media (max-width: 480px) {
  .form-row { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<!-- LEFT PANEL -->
<div class="left-panel">
  <div class="lp-logo"><i class="fas fa-user-plus"></i></div>
  <div class="lp-title">Join Esho Desh Gori</div>
  <div class="lp-sub">এসো দেশ গড়ি — Building Bangladesh Together</div>
  <div class="lp-divider"></div>

  <div class="lp-steps">
    <div class="lp-step">
      <div class="step-circle">1</div>
      <div class="step-info">
        <div class="si-title">Create Your Account</div>
        <div class="si-sub">Fill in your details to register in under a minute</div>
      </div>
    </div>
    <div class="lp-step">
      <div class="step-circle">2</div>
      <div class="step-info">
        <div class="si-title">Choose a Cause</div>
        <div class="si-sub">Pick from 10 charity campaigns that matter to you</div>
      </div>
    </div>
    <div class="lp-step">
      <div class="step-circle">3</div>
      <div class="step-info">
        <div class="si-title">Donate Securely</div>
        <div class="si-sub">bKash, Nagad, Card or Bank — any method you prefer</div>
      </div>
    </div>
    <div class="lp-step">
      <div class="step-circle">4</div>
      <div class="step-info">
        <div class="si-title">Track Your Impact</div>
        <div class="si-sub">See your donation history and photos from the field</div>
      </div>
    </div>
  </div>

  <div class="lp-login-box">
    <p>Already have an account?</p>
    <a href="<?= $base ?>/auth/login.php?mode=login" class="lp-login-btn">
      <i class="fas fa-right-to-bracket"></i> Login Now
    </a>
  </div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
  <div class="form-wrap">

    <a href="<?= $base ?>/auth/login.php" class="back-btn-sm">
      <i class="fas fa-arrow-left"></i> Back to login
    </a>

    <div class="form-heading">Create Your Account</div>
    <div class="form-sub">All fields marked <span style="color:#e53e3e;">*</span> are required</div>

    <?php if ($errors): ?>
      <div class="alert-error">
        <strong><i class="fas fa-exclamation-circle"></i> Please fix the following:</strong>
        <ul style="margin-top:6px;">
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

      <div class="form-row">

        <div class="form-group full">
          <label class="form-label">Full Name <span class="req">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-user icon"></i>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($old['name'] ?? '') ?>"
                   placeholder="Your full name" required autofocus>
          </div>
        </div>

        <div class="form-group full">
          <label class="form-label">Email Address <span class="req">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-envelope icon"></i>
            <input type="email" name="email"
                   value="<?= htmlspecialchars($old['email'] ?? '') ?>"
                   placeholder="your@email.com" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Phone Number <span class="req">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-phone icon"></i>
            <input type="text" name="phone" maxlength="11"
                   value="<?= htmlspecialchars($old['phone'] ?? '') ?>"
                   placeholder="01XXXXXXXXX" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">City</label>
          <div class="input-wrap">
            <i class="fas fa-city icon"></i>
            <input type="text" name="city"
                   value="<?= htmlspecialchars($old['city'] ?? '') ?>"
                   placeholder="Dhaka">
          </div>
        </div>

        <div class="form-group full">
          <label class="form-label">Address</label>
          <div class="input-wrap">
            <i class="fas fa-location-dot icon"></i>
            <input type="text" name="address"
                   value="<?= htmlspecialchars($old['address'] ?? '') ?>"
                   placeholder="Your full address">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Password <span class="req">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-lock icon"></i>
            <input type="password" name="password" id="regPw"
                   placeholder="Min 6 characters" required oninput="checkStrength(this.value)">
            <button type="button" class="pw-toggle" onclick="togglePw('regPw',this)">
              <i class="fas fa-eye"></i>
            </button>
          </div>
          <div class="pw-strength"><div class="pw-strength-bar" id="strengthBar"></div></div>
          <div class="pw-hint" id="strengthHint">Enter a password</div>
        </div>

        <div class="form-group">
          <label class="form-label">Confirm Password <span class="req">*</span></label>
          <div class="input-wrap">
            <i class="fas fa-lock icon"></i>
            <input type="password" name="confirm" id="regConfirm"
                   placeholder="Repeat password" required>
            <button type="button" class="pw-toggle" onclick="togglePw('regConfirm',this)">
              <i class="fas fa-eye"></i>
            </button>
          </div>
        </div>

      </div><!-- end form-row -->

      <button type="submit" class="btn-register">
        <i class="fas fa-user-plus"></i> Create Account
      </button>
    </form>

    <div class="terms-note">
      By registering, you agree to our
      <a href="#" style="color:var(--green);">Terms of Service</a> &amp;
      <a href="#" style="color:var(--green);">Privacy Policy</a>
    </div>

  </div>
</div>

<script>
function togglePw(id, btn) {
  var inp = document.getElementById(id);
  var ico = btn.querySelector('i');
  inp.type = inp.type === 'password' ? 'text' : 'password';
  ico.classList.toggle('fa-eye');
  ico.classList.toggle('fa-eye-slash');
}

function checkStrength(val) {
  var bar  = document.getElementById('strengthBar');
  var hint = document.getElementById('strengthHint');
  var strength = 0;
  if (val.length >= 6)  strength++;
  if (val.length >= 10) strength++;
  if (/[A-Z]/.test(val))  strength++;
  if (/[0-9]/.test(val))  strength++;
  if (/[^A-Za-z0-9]/.test(val)) strength++;

  var configs = [
    { w:'0%',   bg:'#e5e7eb', txt:'Enter a password' },
    { w:'25%',  bg:'#ef4444', txt:'Weak' },
    { w:'50%',  bg:'#f97316', txt:'Fair' },
    { w:'75%',  bg:'#eab308', txt:'Good' },
    { w:'100%', bg:'#22c55e', txt:'Strong ✓' },
  ];
  var c = configs[Math.min(strength, 4)];
  bar.style.width      = c.w;
  bar.style.background = c.bg;
  hint.textContent     = c.txt;
  hint.style.color     = c.bg;
}
</script>
</body>
</html>
