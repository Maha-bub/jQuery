================================================================
  ESHO DESH GORI — DEVELOPER GUIDE
  Last updated: Auth + DB overhaul
================================================================

SETUP
-----
1. Copy folder to:  C:/xampp/htdocs/edg-project/
2. Import database: mysql -u root -p < database.sql
3. Edit includes/db.php — set your DB credentials
4. Open:  http://localhost/edg-project/

DB CREDENTIALS (includes/db.php)
---------------------------------
DB_HOST = localhost
DB_NAME = esho_desh_gori
DB_USER = root
DB_PASS = (your password)

DEFAULT ADMIN LOGIN
-------------------
URL:      http://localhost/edg-project/auth/admin-login.php
Email:    admin@eshodeshgori.com
Password: Admin@1234
⚠️  Change password immediately after first login!

DONOR REGISTRATION
------------------
URL: http://localhost/edg-project/auth/login.php
     → Create Account or Continue as Guest

================================================================
WHAT'S NEW — AUTH + DB UPDATE
================================================================

LOGIN PAGE (auth/login.php)
  ✔ Two-panel modern design (green left / white right)
  ✔ Choice screen: Login/Register OR Guest
  ✔ Password show/hide toggle
  ✔ Flash message support (success after register)
  ✔ Redirect back to intended page after login

REGISTER PAGE (auth/register.php)
  ✔ Two-panel modern design
  ✔ Live password strength meter (Weak/Fair/Good/Strong)
  ✔ Password show/hide toggle
  ✔ Duplicate email check
  ✔ bcrypt password hashing

ADMIN LOGIN (auth/admin-login.php)
  ✔ Dark theme — professional admin feel
  ✔ Brute-force protection:
      5 failed attempts → 5-minute lockout
      Live countdown timer displayed
  ✔ Attempt indicator dots (visual feedback)
  ✔ Password show/hide toggle
  ✔ login_count tracked per session

DATABASE — NEW COLUMNS
-----------------------
users:
  + status          ENUM (active/inactive/banned)
  + email_verified  TINYINT
  + last_login      TIMESTAMP
  + login_count     INT
  + updated_at      TIMESTAMP

admins:
  + last_login      TIMESTAMP
  + login_count     INT
  + is_active       TINYINT
  + updated_at      TIMESTAMP

campaigns:
  + description     TEXT
  + donor_count     INT
  + sort_order      INT
  + updated_at      TIMESTAMP

donations:
  + payment_method  VARCHAR(50)
  + transaction_id  VARCHAR(120)
  + notes           TEXT
  + updated_at      TIMESTAMP

contact_messages:
  + replied_at      TIMESTAMP

================================================================
EXISTING DATABASE? RUN THESE:
(already included at bottom of database.sql)
================================================================
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS status ENUM('active','inactive','banned') DEFAULT 'active' AFTER password,
  ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL AFTER status,
  ADD COLUMN IF NOT EXISTS login_count INT UNSIGNED DEFAULT 0 AFTER last_login,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE admins
  ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL AFTER role,
  ADD COLUMN IF NOT EXISTS login_count INT UNSIGNED DEFAULT 0 AFTER last_login,
  ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1 AFTER login_count,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

================================================================
FILE STRUCTURE
================================================================
edg-project/
├── index.php
├── about-us.php
├── gallery.php
├── contact-us.php
├── donate.php          ← pre-fills amount+project from project pages
├── project.php
│
├── auth/
│   ├── login.php       ← ✨ new design (choice + login form)
│   ├── register.php    ← ✨ new design + pw strength meter
│   ├── admin-login.php ← ✨ dark theme + lockout protection
│   ├── guest.php
│   ├── logout.php
│   └── admin-logout.php
│
├── admin/
│   ├── index.php       (Dashboard)
│   ├── campaigns.php
│   ├── donations.php
│   ├── users.php
│   └── messages.php
│
├── projects/
│   ├── _project-template.php  ← sidebar quick-donate form
│   └── (10 project pages)
│
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── db.php          ← edit DB credentials here
│   └── auth.php        ← session + CSRF + flash helpers
│
├── assets/
│   ├── css/
│   │   ├── style.css
│   │   └── project-style.css
│   ├── js/
│   │   └── script.js
│   └── images/         ← put your images here
│
└── database.sql        ← ✨ updated schema + ALTER scripts
