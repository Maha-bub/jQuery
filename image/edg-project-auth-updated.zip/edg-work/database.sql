-- ============================================================
--  database.sql  —  Esho Desh Gori  (Full Web App Schema)
--  Run:  mysql -u root -p esho_desh_gori < database.sql
--
--  Tables:
--    1. users            — registered donors
--    2. admins           — admin panel users
--    3. campaigns        — charity project campaigns
--    4. donations        — all donation records
--    5. contact_messages — contact form submissions
-- ============================================================

CREATE DATABASE IF NOT EXISTS esho_desh_gori
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE esho_desh_gori;

-- ────────────────────────────────────────────────────────────
-- TABLE 1: users  (registered donors)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    name            VARCHAR(120)    NOT NULL,
    email           VARCHAR(180)    NOT NULL,
    phone           VARCHAR(20)     NOT NULL,
    city            VARCHAR(80)     DEFAULT '',
    address         VARCHAR(255)    DEFAULT '',
    password        VARCHAR(255)    NOT NULL,
    -- account state
    status          ENUM('active','inactive','banned') DEFAULT 'active',
    -- tracking
    email_verified  TINYINT(1)      DEFAULT 0,
    last_login      TIMESTAMP       NULL DEFAULT NULL,
    login_count     INT UNSIGNED    DEFAULT 0,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_users_email (email),
    INDEX   idx_users_status  (status),
    INDEX   idx_users_phone   (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ────────────────────────────────────────────────────────────
-- TABLE 2: admins
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    name            VARCHAR(120)    NOT NULL,
    email           VARCHAR(180)    NOT NULL,
    password        VARCHAR(255)    NOT NULL,
    role            ENUM('super_admin','editor') DEFAULT 'editor',
    -- tracking
    last_login      TIMESTAMP       NULL DEFAULT NULL,
    login_count     INT UNSIGNED    DEFAULT 0,
    is_active       TINYINT(1)      DEFAULT 1,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_admins_email (email),
    INDEX   idx_admins_role     (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ────────────────────────────────────────────────────────────
-- TABLE 3: campaigns  (charity projects)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS campaigns (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    slug            VARCHAR(100)    NOT NULL,
    title           VARCHAR(150)    NOT NULL,
    category        VARCHAR(80)     NOT NULL,
    icon            VARCHAR(100)    NOT NULL DEFAULT 'fas fa-heart',
    color           VARCHAR(200)    DEFAULT '#1a7a4a',
    goal_amount     DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    raised_amount   DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    pct_funded      INT             NOT NULL DEFAULT 0,
    intro           TEXT            NULL,
    description     TEXT            NULL,
    -- meta
    status          ENUM('active','inactive') DEFAULT 'active',
    donor_count     INT UNSIGNED    DEFAULT 0,
    sort_order      INT             DEFAULT 0,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_campaigns_slug   (slug),
    INDEX   idx_campaigns_status    (status),
    INDEX   idx_campaigns_category  (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ────────────────────────────────────────────────────────────
-- TABLE 4: donations
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS donations (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    -- relations (nullable — guest donors have no user_id)
    user_id         INT UNSIGNED    DEFAULT NULL,
    campaign_id     INT UNSIGNED    DEFAULT NULL,
    -- form fields
    project         VARCHAR(150)    NOT NULL,
    intention       VARCHAR(80)     NOT NULL,
    name            VARCHAR(120)    NOT NULL,
    phone           VARCHAR(20)     NOT NULL,
    city            VARCHAR(80)     NOT NULL,
    address         VARCHAR(255)    NOT NULL,
    amount          DECIMAL(10,2)   NOT NULL,
    -- payment
    payment_method  VARCHAR(50)     DEFAULT NULL,
    transaction_id  VARCHAR(120)    DEFAULT NULL,
    status          ENUM('pending','completed','failed') DEFAULT 'pending',
    -- meta
    notes           TEXT            DEFAULT NULL,
    ip_address      VARCHAR(45)     DEFAULT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    CONSTRAINT fk_donations_user
        FOREIGN KEY (user_id)     REFERENCES users(id)     ON DELETE SET NULL,
    CONSTRAINT fk_donations_campaign
        FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE SET NULL,
    INDEX   idx_donations_status      (status),
    INDEX   idx_donations_user        (user_id),
    INDEX   idx_donations_campaign    (campaign_id),
    INDEX   idx_donations_created_at  (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ────────────────────────────────────────────────────────────
-- TABLE 5: contact_messages
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    name            VARCHAR(120)    NOT NULL,
    email           VARCHAR(180)    NOT NULL,
    phone           VARCHAR(20)     NOT NULL,
    gender          VARCHAR(10)     NOT NULL,
    address         VARCHAR(255)    NOT NULL,
    message         TEXT            NOT NULL,
    -- status
    is_read         TINYINT(1)      DEFAULT 0,
    replied_at      TIMESTAMP       NULL DEFAULT NULL,
    -- meta
    ip_address      VARCHAR(45)     DEFAULT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX   idx_messages_is_read (is_read),
    INDEX   idx_messages_email   (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- SEED DATA — campaigns
-- ============================================================
INSERT IGNORE INTO campaigns
    (slug, title, category, icon, color, goal_amount, raised_amount, pct_funded, intro, sort_order)
VALUES
('school-bags',       'School Bags',              'Education',  'fas fa-backpack',          'linear-gradient(135deg,#1a3a5c,#3b82c4)', 100000, 72000,  72, 'Providing school bags and stationery to underprivileged children.',  1),
('income-generating', 'Income Generating',         'Livelihood', 'fas fa-seedling',          'linear-gradient(135deg,#1a5c2e,#4caf73)', 100000, 55000,  55, 'Skill training and small business support for low-income families.', 2),
('healing-bangladesh','Healing Bangladesh',        'Healthcare', 'fas fa-heart-pulse',       'linear-gradient(135deg,#0a3d3a,#0d9488)', 100000, 63000,  63, 'Free medical camps and medicine distribution in rural areas.',        3),
('donate-a-house',    'Donate a House',            'Shelter',    'fas fa-house',             'linear-gradient(135deg,#4a1a0a,#c06520)', 200000, 96000,  48, 'Building safe homes for homeless and extreme-poor families.',         4),
('build-a-masjid',    'Build a Masjid',            'Faith',      'fas fa-mosque',            'linear-gradient(135deg,#2d1a5c,#7c3aed)', 300000, 240000, 80, 'Constructing a masjid for an underserved rural community.',           5),
('gift-of-water',     'Tubewell / Gift of Water',  'Water',      'fas fa-droplet',           'linear-gradient(135deg,#0c3d4a,#0891b2)', 50000,  45000,  90, 'Installing tubewells for villages that lack clean water.',            6),
('donate-a-quran',    'Donate a Quran',            'Quran',      'fas fa-book-open',         'linear-gradient(135deg,#1a1a4a,#4f46e5)', 50000,  33000,  66, 'Gifting Qurans to mosques and madrasas in need.',                     7),
('emergency-aid',     'Emergency Aid',             'Emergency',  'fas fa-hand-holding-heart','linear-gradient(135deg,#4a0a1a,#e11d48)', 100000, 85000,  85, 'Rapid relief for families affected by floods and disasters.',         8),
('feed-daily',        'Feed Daily',                'Food',       'fas fa-bowl-food',         'linear-gradient(135deg,#1a3a10,#4a8c20)', 100000, 77000,  77, 'Daily nutritious meals for the hungry and homeless.',                 9),
('sponsor-yateem',    'Sponsored A Yateem',        'Orphan',     'fas fa-child',             'linear-gradient(135deg,#3a1a10,#c05020)', 100000, 60000,  60, 'Monthly sponsorship for orphaned children covering all their needs.', 10);


-- ============================================================
-- SEED DATA — Default Super Admin
-- Email:    admin@eshodeshgori.com
-- Password: Admin@1234  (change after first login!)
-- ============================================================
INSERT IGNORE INTO admins (name, email, password, role) VALUES (
    'Mahabubul Alam',
    'admin@eshodeshgori.com',
    '$2y$12$bIR1Su8K9sUg.al53nj7mu3/2QhO2hsPmWakZfUd2sJ2CEgpfwGVC',
    'super_admin'
);


-- ============================================================
-- ALTER SCRIPTS — run these if database ALREADY EXISTS
-- (safe to skip if running fresh)
-- ============================================================

-- Add new columns to existing users table
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS status         ENUM('active','inactive','banned') DEFAULT 'active' AFTER password,
    ADD COLUMN IF NOT EXISTS email_verified TINYINT(1)  DEFAULT 0           AFTER status,
    ADD COLUMN IF NOT EXISTS last_login     TIMESTAMP   NULL DEFAULT NULL   AFTER email_verified,
    ADD COLUMN IF NOT EXISTS login_count    INT UNSIGNED DEFAULT 0          AFTER last_login,
    ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMP   DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- Add new columns to existing admins table
ALTER TABLE admins
    ADD COLUMN IF NOT EXISTS last_login  TIMESTAMP   NULL DEFAULT NULL   AFTER role,
    ADD COLUMN IF NOT EXISTS login_count INT UNSIGNED DEFAULT 0          AFTER last_login,
    ADD COLUMN IF NOT EXISTS is_active   TINYINT(1)  DEFAULT 1          AFTER login_count,
    ADD COLUMN IF NOT EXISTS updated_at  TIMESTAMP   DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- Add new columns to existing campaigns table
ALTER TABLE campaigns
    ADD COLUMN IF NOT EXISTS description TEXT   NULL           AFTER intro,
    ADD COLUMN IF NOT EXISTS donor_count INT UNSIGNED DEFAULT 0 AFTER status,
    ADD COLUMN IF NOT EXISTS sort_order  INT          DEFAULT 0 AFTER donor_count,
    ADD COLUMN IF NOT EXISTS updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- Add new columns to existing donations table
ALTER TABLE donations
    ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50)  DEFAULT NULL AFTER amount,
    ADD COLUMN IF NOT EXISTS transaction_id VARCHAR(120) DEFAULT NULL AFTER payment_method,
    ADD COLUMN IF NOT EXISTS notes          TEXT         DEFAULT NULL AFTER status,
    ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- Add new columns to existing contact_messages table
ALTER TABLE contact_messages
    ADD COLUMN IF NOT EXISTS replied_at TIMESTAMP NULL DEFAULT NULL AFTER is_read;

